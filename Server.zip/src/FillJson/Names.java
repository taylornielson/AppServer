package FillJson;

import java.util.ArrayList;

public class Names {
    ArrayList<String> data = new ArrayList<String>();
}
