package FillJson;

import java.util.ArrayList;

public class Locations {
    ArrayList<Location> data = new ArrayList<Location>();

}
